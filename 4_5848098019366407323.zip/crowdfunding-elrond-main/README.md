# crowdfunding-elrond
Demo crowdfunding smart contract on elrond blockchain
